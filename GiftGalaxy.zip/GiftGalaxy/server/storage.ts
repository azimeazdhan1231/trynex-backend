import { users, products, cartItems, orders, type User, type InsertUser, type Product, type InsertProduct, type CartItem, type InsertCartItem, type Order, type InsertOrder } from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Product methods
  getAllProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getFeaturedProducts(): Promise<Product[]>;
  getProductsByCategory(category: string): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // Cart methods
  getCartItems(sessionId: string): Promise<CartItem[]>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, quantity: number): Promise<CartItem | undefined>;
  removeFromCart(id: number): Promise<boolean>;
  clearCart(sessionId: string): Promise<boolean>;
  
  // Order methods
  createOrder(order: InsertOrder): Promise<Order>;
  getOrder(id: number): Promise<Order | undefined>;
  getAllOrders(): Promise<Order[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private products: Map<number, Product>;
  private cartItems: Map<number, CartItem>;
  private orders: Map<number, Order>;
  private currentUserId: number;
  private currentProductId: number;
  private currentCartItemId: number;
  private currentOrderId: number;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.cartItems = new Map();
    this.orders = new Map();
    this.currentUserId = 1;
    this.currentProductId = 1;
    this.currentCartItemId = 1;
    this.currentOrderId = 1;
    
    // Initialize with sample products
    this.initializeProducts();
  }

  private initializeProducts() {
    const sampleProducts: InsertProduct[] = [
      {
        name: "বেসিক কটন টি-শার্ট",
        nameEn: "Basic Cotton T-Shirt",
        description: "উচ্চ মানের কটন টি-শার্ট কাস্টম ডিজাইন সহ",
        descriptionEn: "High quality cotton t-shirt with custom design",
        price: 450,
        category: "t-shirt",
        image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop",
        images: [
          "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop",
          "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=400&h=400&fit=crop"
        ],
        isCustomizable: true,
        isFeatured: true,
        inStock: true
      },
      {
        name: "প্রিমিয়াম কটন টি-শার্ট",
        nameEn: "Premium Cotton T-Shirt",
        description: "প্রিমিয়াম কোয়ালিটি কটন টি-শার্ট",
        descriptionEn: "Premium quality cotton t-shirt",
        price: 550,
        category: "t-shirt",
        image: "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=400&h=400&fit=crop",
        isCustomizable: true,
        isFeatured: true,
        inStock: true
      },
      {
        name: "প্রিমিয়াম ড্রপশোল্ডার টি-শার্ট",
        nameEn: "Premium Drop-shoulder T-Shirt",
        description: "প্রিমিয়াম ড্রপশোল্ডার টি-শার্ট কাস্টম ডিজাইন সহ",
        descriptionEn: "Premium drop-shoulder t-shirt with custom design",
        price: 580,
        category: "t-shirt",
        image: "https://images.unsplash.com/photo-1583743814966-8936f37f9273?w=400&h=400&fit=crop",
        isCustomizable: true,
        isFeatured: true,
        inStock: true
      },
      {
        name: "কাস্টমাইজেবল মগ",
        nameEn: "Customizable Mug",
        description: "কাস্টম ডিজাইন সহ সিরামিক মগ",
        descriptionEn: "Ceramic mug with custom design",
        price: 550,
        originalPrice: 600,
        category: "mug",
        image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=400&fit=crop",
        isCustomizable: true,
        isFeatured: true,
        discountPercentage: 8,
        specialOffer: "৩ দিনের অফারে",
        inStock: true
      },
      {
        name: "কাস্টমাইজেবল টাম্বলার",
        nameEn: "Customizable Tumbler",
        description: "কাস্টম ডিজাইন সহ ইনসুলেটেড টাম্বলার",
        descriptionEn: "Insulated tumbler with custom design",
        price: 700,
        category: "tumbler",
        image: "https://images.unsplash.com/photo-1544145945-f90425340c7e?w=400&h=400&fit=crop",
        isCustomizable: true,
        isFeatured: true,
        specialOffer: "২টি কিনলে ২০০ টাকা ছাড়",
        inStock: true
      },
      {
        name: "পান্ডা গিফট সেট",
        nameEn: "Panda Gift Set",
        description: "মগ, টি-শার্ট এবং টাম্বলার সহ সম্পূর্ণ গিফট সেট",
        descriptionEn: "Complete gift set with mug, t-shirt and tumbler",
        price: 1490,
        originalPrice: 2100,
        category: "gift-set",
        image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop",
        isCustomizable: true,
        isFeatured: true,
        discountPercentage: 29,
        specialOffer: "৬১০ টাকা ছাড়!",
        inStock: true
      }
    ];

    sampleProducts.forEach(product => {
      this.createProduct(product);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Product methods
  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getFeaturedProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(product => product.isFeatured);
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter(product => product.category === category);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const product: Product = { 
      ...insertProduct, 
      id,
      createdAt: new Date()
    };
    this.products.set(id, product);
    return product;
  }

  // Cart methods
  async getCartItems(sessionId: string): Promise<CartItem[]> {
    return Array.from(this.cartItems.values()).filter(item => item.sessionId === sessionId);
  }

  async addToCart(insertCartItem: InsertCartItem): Promise<CartItem> {
    const id = this.currentCartItemId++;
    const cartItem: CartItem = { 
      ...insertCartItem, 
      id,
      createdAt: new Date()
    };
    this.cartItems.set(id, cartItem);
    return cartItem;
  }

  async updateCartItem(id: number, quantity: number): Promise<CartItem | undefined> {
    const item = this.cartItems.get(id);
    if (item) {
      item.quantity = quantity;
      this.cartItems.set(id, item);
    }
    return item;
  }

  async removeFromCart(id: number): Promise<boolean> {
    return this.cartItems.delete(id);
  }

  async clearCart(sessionId: string): Promise<boolean> {
    const items = await this.getCartItems(sessionId);
    items.forEach(item => this.cartItems.delete(item.id));
    return true;
  }

  // Order methods
  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.currentOrderId++;
    const order: Order = { 
      ...insertOrder, 
      id,
      createdAt: new Date()
    };
    this.orders.set(id, order);
    return order;
  }

  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getAllOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }
}

export const storage = new MemStorage();
