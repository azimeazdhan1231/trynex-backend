import { MongoClient, Db, Collection, ObjectId } from 'mongodb';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import type { 
  AdminCreate, 
  AdminLogin, 
  ProductCreate, 
  ProductUpdate, 
  OrderUpdate, 
  Category, 
  Customer, 
  SiteSettings,
  AnalyticsFilter 
} from '@shared/admin-schema';

export interface Admin {
  _id?: ObjectId;
  username: string;
  email: string;
  password: string;
  role: 'admin' | 'super_admin';
  createdAt: Date;
  lastLogin?: Date;
}

export interface AdminProduct {
  _id?: ObjectId;
  name: string;
  nameEn?: string;
  description: string;
  descriptionEn?: string;
  price: number;
  originalPrice?: number;
  category: string;
  image: string;
  images: string[];
  isCustomizable: boolean;
  isFeatured: boolean;
  discountPercentage: number;
  specialOffer?: string;
  inStock: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface AdminOrder {
  _id?: ObjectId;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  customerAddress?: string;
  items: Array<{
    productId: string;
    productName: string;
    quantity: number;
    price: number;
    customization?: string;
  }>;
  totalAmount: number;
  status: 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface AnalyticsData {
  totalOrders: number;
  totalRevenue: number;
  totalProducts: number;
  totalCustomers: number;
  recentOrders: AdminOrder[];
  topProducts: Array<{
    productId: string;
    productName: string;
    totalSold: number;
    revenue: number;
  }>;
  salesByCategory: Array<{
    category: string;
    totalSales: number;
    revenue: number;
  }>;
  salesByMonth: Array<{
    month: string;
    sales: number;
    revenue: number;
  }>;
}

export class AdminStorage {
  private db: Db;
  private admins: Collection<Admin>;
  private products: Collection<AdminProduct>;
  private orders: Collection<AdminOrder>;
  private categories: Collection<Category>;
  private customers: Collection<Customer>;
  private settings: Collection<SiteSettings>;

  constructor(db: Db) {
    this.db = db;
    this.admins = db.collection('admins');
    this.products = db.collection('products');
    this.orders = db.collection('orders');
    this.categories = db.collection('categories');
    this.customers = db.collection('customers');
    this.settings = db.collection('settings');
  }

  // Admin authentication methods
  async createAdmin(adminData: AdminCreate): Promise<Admin> {
    const existingAdmin = await this.admins.findOne({ 
      $or: [{ username: adminData.username }, { email: adminData.email }] 
    });
    
    if (existingAdmin) {
      throw new Error('Admin with this username or email already exists');
    }

    const hashedPassword = await bcrypt.hash(adminData.password, 12);
    
    const admin: Admin = {
      ...adminData,
      password: hashedPassword,
      createdAt: new Date(),
    };

    const result = await this.admins.insertOne(admin);
    return { ...admin, _id: result.insertedId };
  }

  async loginAdmin(loginData: AdminLogin): Promise<{ admin: Omit<Admin, 'password'>, token: string }> {
    const admin = await this.admins.findOne({ username: loginData.username });
    
    if (!admin || !await bcrypt.compare(loginData.password, admin.password)) {
      throw new Error('Invalid credentials');
    }

    // Update last login
    await this.admins.updateOne(
      { _id: admin._id },
      { $set: { lastLogin: new Date() } }
    );

    const token = jwt.sign(
      { adminId: admin._id, username: admin.username, role: admin.role },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '7d' }
    );

    const { password, ...adminWithoutPassword } = admin;
    return { admin: adminWithoutPassword, token };
  }

  // Product management methods
  async getAllProducts(page = 1, limit = 20, search?: string, category?: string): Promise<{ products: AdminProduct[], total: number }> {
    const filter: any = {};
    
    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }
    
    if (category) {
      filter.category = category;
    }

    const total = await this.products.countDocuments(filter);
    const products = await this.products
      .find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .toArray();

    return { products, total };
  }

  async getProduct(id: string): Promise<AdminProduct | null> {
    return await this.products.findOne({ _id: new ObjectId(id) });
  }

  async createProduct(productData: ProductCreate): Promise<AdminProduct> {
    const product: AdminProduct = {
      ...productData,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const result = await this.products.insertOne(product);
    return { ...product, _id: result.insertedId };
  }

  async updateProduct(id: string, updateData: ProductUpdate): Promise<AdminProduct | null> {
    const result = await this.products.findOneAndUpdate(
      { _id: new ObjectId(id) },
      { 
        $set: { 
          ...updateData, 
          updatedAt: new Date() 
        } 
      },
      { returnDocument: 'after' }
    );

    return result;
  }

  async deleteProduct(id: string): Promise<boolean> {
    const result = await this.products.deleteOne({ _id: new ObjectId(id) });
    return result.deletedCount > 0;
  }

  // Order management methods
  async getAllOrders(page = 1, limit = 20, status?: string, search?: string): Promise<{ orders: AdminOrder[], total: number }> {
    const filter: any = {};
    
    if (status) {
      filter.status = status;
    }
    
    if (search) {
      filter.$or = [
        { orderNumber: { $regex: search, $options: 'i' } },
        { customerName: { $regex: search, $options: 'i' } },
        { customerPhone: { $regex: search, $options: 'i' } }
      ];
    }

    const total = await this.orders.countDocuments(filter);
    const orders = await this.orders
      .find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .toArray();

    return { orders, total };
  }

  async getOrder(id: string): Promise<AdminOrder | null> {
    return await this.orders.findOne({ _id: new ObjectId(id) });
  }

  async updateOrderStatus(id: string, updateData: OrderUpdate): Promise<AdminOrder | null> {
    const result = await this.orders.findOneAndUpdate(
      { _id: new ObjectId(id) },
      { 
        $set: { 
          ...updateData, 
          updatedAt: new Date() 
        } 
      },
      { returnDocument: 'after' }
    );

    return result;
  }

  // Analytics methods
  async getAnalytics(filter?: AnalyticsFilter): Promise<AnalyticsData> {
    const dateFilter: any = {};
    
    if (filter?.startDate || filter?.endDate) {
      dateFilter.createdAt = {};
      if (filter.startDate) dateFilter.createdAt.$gte = new Date(filter.startDate);
      if (filter.endDate) dateFilter.createdAt.$lte = new Date(filter.endDate);
    }

    // Get basic counts
    const [totalOrders, totalProducts, totalCustomers] = await Promise.all([
      this.orders.countDocuments(dateFilter),
      this.products.countDocuments(),
      this.customers.countDocuments()
    ]);

    // Get total revenue
    const revenueResult = await this.orders.aggregate([
      { $match: { ...dateFilter, status: { $ne: 'cancelled' } } },
      { $group: { _id: null, totalRevenue: { $sum: '$totalAmount' } } }
    ]).toArray();
    
    const totalRevenue = revenueResult[0]?.totalRevenue || 0;

    // Get recent orders
    const recentOrders = await this.orders
      .find(dateFilter)
      .sort({ createdAt: -1 })
      .limit(10)
      .toArray();

    // Get top products
    const topProducts = await this.orders.aggregate([
      { $match: { ...dateFilter, status: { $ne: 'cancelled' } } },
      { $unwind: '$items' },
      { 
        $group: { 
          _id: '$items.productId',
          productName: { $first: '$items.productName' },
          totalSold: { $sum: '$items.quantity' },
          revenue: { $sum: { $multiply: ['$items.quantity', '$items.price'] } }
        }
      },
      { $sort: { totalSold: -1 } },
      { $limit: 10 },
      {
        $project: {
          productId: '$_id',
          productName: 1,
          totalSold: 1,
          revenue: 1,
          _id: 0
        }
      }
    ]).toArray();

    // Get sales by category
    const salesByCategory = await this.orders.aggregate([
      { $match: { ...dateFilter, status: { $ne: 'cancelled' } } },
      { $unwind: '$items' },
      {
        $lookup: {
          from: 'products',
          localField: 'items.productId',
          foreignField: '_id',
          as: 'product'
        }
      },
      { $unwind: '$product' },
      {
        $group: {
          _id: '$product.category',
          totalSales: { $sum: '$items.quantity' },
          revenue: { $sum: { $multiply: ['$items.quantity', '$items.price'] } }
        }
      },
      {
        $project: {
          category: '$_id',
          totalSales: 1,
          revenue: 1,
          _id: 0
        }
      }
    ]).toArray();

    // Get sales by month
    const salesByMonth = await this.orders.aggregate([
      { $match: { ...dateFilter, status: { $ne: 'cancelled' } } },
      {
        $group: {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' }
          },
          sales: { $sum: 1 },
          revenue: { $sum: '$totalAmount' }
        }
      },
      {
        $project: {
          month: {
            $concat: [
              { $toString: '$_id.year' },
              '-',
              { $toString: '$_id.month' }
            ]
          },
          sales: 1,
          revenue: 1,
          _id: 0
        }
      },
      { $sort: { month: 1 } }
    ]).toArray();

    return {
      totalOrders,
      totalRevenue,
      totalProducts,
      totalCustomers,
      recentOrders,
      topProducts,
      salesByCategory,
      salesByMonth
    };
  }

  // Category methods
  async getAllCategories(): Promise<Category[]> {
    return await this.categories.find({}).sort({ name: 1 }).toArray();
  }

  async createCategory(categoryData: Category): Promise<Category> {
    const result = await this.categories.insertOne(categoryData);
    return { ...categoryData, _id: result.insertedId };
  }

  async updateCategory(id: string, categoryData: Partial<Category>): Promise<Category | null> {
    const result = await this.categories.findOneAndUpdate(
      { _id: new ObjectId(id) },
      { $set: categoryData },
      { returnDocument: 'after' }
    );
    return result;
  }

  async deleteCategory(id: string): Promise<boolean> {
    const result = await this.categories.deleteOne({ _id: new ObjectId(id) });
    return result.deletedCount > 0;
  }

  // Settings methods
  async getSettings(): Promise<SiteSettings | null> {
    return await this.settings.findOne({});
  }

  async updateSettings(settingsData: SiteSettings): Promise<SiteSettings> {
    const result = await this.settings.findOneAndReplace(
      {},
      settingsData,
      { upsert: true, returnDocument: 'after' }
    );
    return result!;
  }

  // Initialize default admin
  async initializeDefaultAdmin(): Promise<void> {
    const adminExists = await this.admins.findOne({});
    
    if (!adminExists) {
      await this.createAdmin({
        username: 'admin',
        email: 'admin@trynex.com',
        password: 'admin123',
        role: 'super_admin'
      });
      console.log('Default admin created: username: admin, password: admin123');
    }
  }
}