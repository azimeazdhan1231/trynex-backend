import type { Express } from "express";
import { AdminStorage } from "./admin-storage";
import { dbManager } from "./db";
import { 
  authenticateAdmin, 
  requireSuperAdmin, 
  loginRateLimit, 
  adminRateLimit,
  uploadRateLimit,
  validateInput,
  type AuthenticatedRequest 
} from "./admin-middleware";
import {
  adminLoginSchema,
  adminCreateSchema,
  productCreateSchema,
  productUpdateSchema,
  orderUpdateSchema,
  analyticsFilterSchema,
  categorySchema,
  siteSettingsSchema
} from "@shared/admin-schema";
import multer from 'multer';
import sharp from 'sharp';
import { nanoid } from 'nanoid';
import path from 'path';
import fs from 'fs/promises';

// Configure multer for file uploads
const storage = multer.memoryStorage();
const upload = multer({
  storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  },
});

export async function registerAdminRoutes(app: Express): Promise<void> {
  const db = dbManager.getDb();
  const adminStorage = new AdminStorage(db);
  
  // Initialize default admin
  await adminStorage.initializeDefaultAdmin();

  // Ensure uploads directory exists
  const uploadsDir = './uploads';
  try {
    await fs.access(uploadsDir);
  } catch {
    await fs.mkdir(uploadsDir, { recursive: true });
  }

  // Authentication routes
  app.post("/api/admin/login", loginRateLimit, validateInput(adminLoginSchema), async (req, res) => {
    try {
      const result = await adminStorage.loginAdmin(req.body);
      res.json(result);
    } catch (error: any) {
      res.status(401).json({ message: error.message });
    }
  });

  app.post("/api/admin/create", authenticateAdmin, requireSuperAdmin, validateInput(adminCreateSchema), async (req: AuthenticatedRequest, res) => {
    try {
      const admin = await adminStorage.createAdmin(req.body);
      const { password, ...adminWithoutPassword } = admin;
      res.status(201).json(adminWithoutPassword);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Dashboard analytics
  app.get("/api/admin/analytics", authenticateAdmin, adminRateLimit, async (req: AuthenticatedRequest, res) => {
    try {
      const filter = analyticsFilterSchema.parse(req.query);
      const analytics = await adminStorage.getAnalytics(filter);
      res.json(analytics);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Product management routes
  app.get("/api/admin/products", authenticateAdmin, adminRateLimit, async (req: AuthenticatedRequest, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const search = req.query.search as string;
      const category = req.query.category as string;
      
      const result = await adminStorage.getAllProducts(page, limit, search, category);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/products/:id", authenticateAdmin, adminRateLimit, async (req: AuthenticatedRequest, res) => {
    try {
      const product = await adminStorage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/products", authenticateAdmin, adminRateLimit, validateInput(productCreateSchema), async (req: AuthenticatedRequest, res) => {
    try {
      const product = await adminStorage.createProduct(req.body);
      res.status(201).json(product);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/admin/products/:id", authenticateAdmin, adminRateLimit, validateInput(productUpdateSchema), async (req: AuthenticatedRequest, res) => {
    try {
      const product = await adminStorage.updateProduct(req.params.id, req.body);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/admin/products/:id", authenticateAdmin, requireSuperAdmin, adminRateLimit, async (req: AuthenticatedRequest, res) => {
    try {
      const deleted = await adminStorage.deleteProduct(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json({ message: "Product deleted successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Image upload route
  app.post("/api/admin/upload", authenticateAdmin, uploadRateLimit, upload.single('image'), async (req: AuthenticatedRequest, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }

      const fileId = nanoid();
      const fileName = `${fileId}.webp`;
      const filePath = path.join(uploadsDir, fileName);

      // Process and optimize image
      await sharp(req.file.buffer)
        .resize(800, 800, { 
          fit: 'inside',
          withoutEnlargement: true 
        })
        .webp({ quality: 85 })
        .toFile(filePath);

      const imageUrl = `/uploads/${fileName}`;
      res.json({ url: imageUrl });
    } catch (error: any) {
      res.status(500).json({ message: "Failed to upload image: " + error.message });
    }
  });

  // Order management routes
  app.get("/api/admin/orders", authenticateAdmin, adminRateLimit, async (req: AuthenticatedRequest, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const status = req.query.status as string;
      const search = req.query.search as string;
      
      const result = await adminStorage.getAllOrders(page, limit, status, search);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/orders/:id", authenticateAdmin, adminRateLimit, async (req: AuthenticatedRequest, res) => {
    try {
      const order = await adminStorage.getOrder(req.params.id);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      res.json(order);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/admin/orders/:id", authenticateAdmin, adminRateLimit, validateInput(orderUpdateSchema), async (req: AuthenticatedRequest, res) => {
    try {
      const order = await adminStorage.updateOrderStatus(req.params.id, req.body);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      res.json(order);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Category management routes
  app.get("/api/admin/categories", authenticateAdmin, adminRateLimit, async (req: AuthenticatedRequest, res) => {
    try {
      const categories = await adminStorage.getAllCategories();
      res.json(categories);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/categories", authenticateAdmin, adminRateLimit, validateInput(categorySchema), async (req: AuthenticatedRequest, res) => {
    try {
      const category = await adminStorage.createCategory(req.body);
      res.status(201).json(category);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/admin/categories/:id", authenticateAdmin, adminRateLimit, validateInput(categorySchema.partial()), async (req: AuthenticatedRequest, res) => {
    try {
      const category = await adminStorage.updateCategory(req.params.id, req.body);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      res.json(category);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/admin/categories/:id", authenticateAdmin, requireSuperAdmin, adminRateLimit, async (req: AuthenticatedRequest, res) => {
    try {
      const deleted = await adminStorage.deleteCategory(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Category not found" });
      }
      res.json({ message: "Category deleted successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Settings management routes
  app.get("/api/admin/settings", authenticateAdmin, adminRateLimit, async (req: AuthenticatedRequest, res) => {
    try {
      const settings = await adminStorage.getSettings();
      res.json(settings);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/admin/settings", authenticateAdmin, requireSuperAdmin, adminRateLimit, validateInput(siteSettingsSchema), async (req: AuthenticatedRequest, res) => {
    try {
      const settings = await adminStorage.updateSettings(req.body);
      res.json(settings);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Serve uploaded files
  app.use('/uploads', (req, res, next) => {
    res.setHeader('Cache-Control', 'public, max-age=86400'); // 24 hours cache
    next();
  });
}