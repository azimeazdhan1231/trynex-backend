
import mongoose from 'mongoose';

let isConnected = false;

export async function initializeDatabase() {
  try {
    if (isConnected) {
      console.log('Database already connected');
      return mongoose.connection.db;
    }

    const mongoURI = process.env.MONGO_URI || 'mongodb+srv://azimeazdhantarafdar:azimeazdhan@cluster0.b6bt3fc.mongodb.net/trynex?retryWrites=true&w=majority&appName=Cluster0';
    
    await mongoose.connect(mongoURI, {
      maxPoolSize: 10,
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000,
    });
    
    isConnected = true;
    console.log('🍃 MongoDB Connected Successfully');
    
    return mongoose.connection.db;
  } catch (error) {
    console.error('❌ MongoDB Connection Error:', error);
    throw error;
  }
}

export const dbManager = {
  getDb: () => mongoose.connection.db
};

export { mongoose as db };
