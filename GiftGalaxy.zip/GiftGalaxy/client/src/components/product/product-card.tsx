import { useState } from "react";
import { useCart } from "@/hooks/use-cart";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import type { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();
  const { toast } = useToast();

  const handleQuantityChange = (change: number) => {
    setQuantity(Math.max(1, quantity + change));
  };

  const handleAddToCart = () => {
    addToCart({
      productId: product.id,
      name: product.name,
      price: product.price,
      quantity: quantity,
      image: product.image
    });

    setQuantity(1);

    toast({
      title: "কার্টে যোগ করা হয়েছে!",
      description: `${product.name} (${quantity}টি) কার্টে যোগ করা হয়েছে।`,
    });
  };

  const getWhatsAppUrl = () => {
    const message = `আমি ${product.name} অর্ডার করতে চাই (${quantity}টি)`;
    return `https://wa.me/8801940689487?text=${encodeURIComponent(message)}`;
  };

  const discountedPrice = product.originalPrice && product.originalPrice > product.price 
    ? product.price 
    : null;

  return (
    <div className="product-card bg-white rounded-2xl shadow-lg overflow-hidden group relative">
      {/* Discount Badge */}
      {product.discountPercentage > 0 && (
        <div className="absolute top-4 left-4 z-10">
          <Badge variant="destructive" className="bg-red-500 text-white">
            {product.discountPercentage}% ছাড়
          </Badge>
        </div>
      )}

      {/* Featured Badge */}
      {product.isFeatured && product.category === 'gift-set' && (
        <div className="absolute top-4 right-4 z-10">
          <Badge className="bg-accent text-white">
            🐼 জনপ্রিয়!
          </Badge>
        </div>
      )}

      {/* Product Image */}
      <div className="relative overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
        />
      </div>

      <div className="p-6">
        <h3 className="text-xl font-semibold text-gray-800 mb-2">{product.name}</h3>
        <p className="text-gray-600 mb-4 text-sm leading-relaxed">{product.description}</p>

        {/* Price Section */}
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-2xl font-bold text-primary">৳{product.price}</span>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-sm text-gray-500 line-through">৳{product.originalPrice}</span>
            )}
          </div>
          {product.specialOffer && (
            <p className="text-sm text-green-600 font-medium">{product.specialOffer}</p>
          )}
        </div>

        {/* Quantity and Add to Cart */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <button 
              onClick={() => handleQuantityChange(-1)}
              className="quantity-btn w-8 h-8 rounded-full border-2 border-gray-300 flex items-center justify-center text-gray-600"
            >
              <i className="fas fa-minus text-xs"></i>
            </button>
            <span className="w-8 text-center font-medium">{quantity}</span>
            <button 
              onClick={() => handleQuantityChange(1)}
              className="quantity-btn w-8 h-8 rounded-full border-2 border-gray-300 flex items-center justify-center text-gray-600"
            >
              <i className="fas fa-plus text-xs"></i>
            </button>
          </div>
          <Button onClick={handleAddToCart} className="btn-premium">
            <i className="fas fa-cart-plus mr-2"></i>
            কার্টে যোগ করুন
          </Button>
        </div>

        {/* Direct Order Button */}
        <a 
          href={getWhatsAppUrl()}
          target="_blank" 
          rel="noopener noreferrer"
          className="w-full bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors text-center block font-medium"
        >
          {product.category === 'gift-set' ? 'এখনই অর্ডার করুন' : 'সরাসরি অর্ডার করুন'}
        </a>
      </div>
    </div>
  );
}