import { useState } from "react";
import { useCart } from "@/hooks/use-cart";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import CartSidebar from "@/components/cart/cart-sidebar";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const { cart } = useCart();

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <>
      <header className="fixed w-full top-0 z-50 glass-effect border-b border-border">
        <nav className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
                <i className="fas fa-gift text-white text-lg"></i>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-800">TryNex</h1>
                <p className="text-xs text-gray-600">Lifestyle</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <button 
                onClick={() => scrollToSection('home')} 
                className="text-gray-700 hover:text-primary transition-colors font-medium"
              >
                হোম
              </button>
              <button 
                onClick={() => scrollToSection('products')} 
                className="text-gray-700 hover:text-primary transition-colors font-medium"
              >
                প্রোডাক্ট
              </button>
              <button 
                onClick={() => scrollToSection('about')} 
                className="text-gray-700 hover:text-primary transition-colors font-medium"
              >
                আমাদের সম্পর্কে
              </button>
              <button 
                onClick={() => scrollToSection('contact')} 
                className="text-gray-700 hover:text-primary transition-colors font-medium"
              >
                যোগাযোগ
              </button>
            </div>

            {/* Cart and Mobile Menu */}
            <div className="flex items-center space-x-4">
              {/* Cart Button */}
              <button 
                onClick={() => setIsCartOpen(true)} 
                className="relative p-2 text-gray-700 hover:text-primary transition-colors"
              >
                <i className="fas fa-shopping-cart text-xl"></i>
                {cart.count > 0 && (
                  <span className="absolute -top-1 -right-1 bg-accent text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {cart.count}
                  </span>
                )}
              </button>

              {/* WhatsApp Button */}
              <a 
                href="https://wa.me/8801940689487" 
                target="_blank" 
                rel="noopener noreferrer"
                className="hidden md:flex items-center space-x-2 bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors"
              >
                <i className="fab fa-whatsapp"></i>
                <span className="text-sm font-medium">অর্ডার করুন</span>
              </a>

              {/* Mobile Menu Button */}
              <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="md:hidden">
                    <i className="fas fa-bars text-xl"></i>
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-80">
                  <div className="flex flex-col space-y-6 pt-6">
                    <button 
                      onClick={() => scrollToSection('home')} 
                      className="text-left text-gray-700 hover:text-primary transition-colors font-medium py-2"
                    >
                      হোম
                    </button>
                    <button 
                      onClick={() => scrollToSection('products')} 
                      className="text-left text-gray-700 hover:text-primary transition-colors font-medium py-2"
                    >
                      প্রোডাক্ট
                    </button>
                    <button 
                      onClick={() => scrollToSection('about')} 
                      className="text-left text-gray-700 hover:text-primary transition-colors font-medium py-2"
                    >
                      আমাদের সম্পর্কে
                    </button>
                    <button 
                      onClick={() => scrollToSection('contact')} 
                      className="text-left text-gray-700 hover:text-primary transition-colors font-medium py-2"
                    >
                      যোগাযোগ
                    </button>
                    <a 
                      href="https://wa.me/8801940689487" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center space-x-2 bg-green-500 text-white px-4 py-3 rounded-lg hover:bg-green-600 transition-colors"
                    >
                      <i className="fab fa-whatsapp"></i>
                      <span className="font-medium">হোয়াটসঅ্যাপে অর্ডার করুন</span>
                    </a>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </nav>
      </header>

      {/* Cart Sidebar */}
      <CartSidebar isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />

      {/* WhatsApp Floating Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <a 
          href="https://wa.me/8801940689487" 
          target="_blank" 
          rel="noopener noreferrer"
          className="w-14 h-14 bg-green-500 rounded-full shadow-2xl flex items-center justify-center text-white hover:scale-110 transition-transform animate-pulse"
        >
          <i className="fab fa-whatsapp text-2xl"></i>
        </a>
      </div>
    </>
  );
}
