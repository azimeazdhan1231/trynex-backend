export default function ContactSection() {
  return (
    <section id="contact" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">যোগাযোগ করুন</h2>
          <p className="text-gray-600 text-lg">আমরা সবসময় আপনার সেবায় প্রস্তুত</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-2xl shadow-lg text-center group hover:shadow-xl transition-shadow">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
              <i className="fab fa-whatsapp text-2xl text-green-600"></i>
            </div>
            <h4 className="text-xl font-semibold text-gray-800 mb-4">WhatsApp অর্ডার</h4>
            <p className="text-gray-600 mb-4">সরাসরি অর্ডার করুন এবং তাৎক্ষণিক উত্তর পান</p>
            <a 
              href="https://wa.me/8801940689487" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-green-600 font-semibold hover:text-green-700 transition-colors"
            >
              +৮৮০১৯৪০৬৮৯৪৮৭
            </a>
          </div>

          <div className="bg-white p-8 rounded-2xl shadow-lg text-center group hover:shadow-xl transition-shadow">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
              <i className="fas fa-phone text-2xl text-blue-600"></i>
            </div>
            <h4 className="text-xl font-semibold text-gray-800 mb-4">ফোন</h4>
            <p className="text-gray-600 mb-4">সরাসরি কল করে জানুন বিস্তারিত</p>
            <a 
              href="tel:01940689487" 
              className="text-blue-600 font-semibold hover:text-blue-700 transition-colors"
            >
              ০১৯৪০-৬৮৯৪৮৭
            </a>
          </div>

          <div className="bg-white p-8 rounded-2xl shadow-lg text-center group hover:shadow-xl transition-shadow">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
              <i className="fas fa-clock text-2xl text-purple-600"></i>
            </div>
            <h4 className="text-xl font-semibold text-gray-800 mb-4">কাজের সময়</h4>
            <div className="text-gray-600 space-y-2 text-sm">
              <div><strong>সোমবার - শুক্রবার:</strong><br />সকাল ৯টা - রাত ৯টা</div>
              <div><strong>শনিবার:</strong><br />সকাল ১০টা - সন্ধ্যা ৬টা</div>
              <div><strong>রবিবার:</strong><br />বিকেল ২টা - রাত ৮টা</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
