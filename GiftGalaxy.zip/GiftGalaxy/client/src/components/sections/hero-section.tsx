import { Button } from "@/components/ui/button";

export default function HeroSection() {
  const scrollToProducts = () => {
    const element = document.getElementById('products');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section id="home" className="pt-20 pb-16 gradient-bg text-white relative overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 opacity-10">
        <img 
          src="https://images.unsplash.com/photo-1549298916-b41d501d3772?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080" 
          alt="Premium gift boxes background" 
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center min-h-[70vh]">
          <div className="animate-slide-up">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              আপনার স্বপ্নের কাস্টমাইজড গিফট 
              <span className="text-accent block mt-2">এখানেই পাবেন</span>
            </h1>
            <p className="text-xl mb-8 text-gray-200 leading-relaxed">
              TryNex Lifestyle এ পাবেন সেরা মানের কাস্টমাইজড টি-শার্ট, মগ, টাম্বলার এবং আরও অনেক কিছু। 
              আপনার পছন্দের ডিজাইনে তৈরি করুন অসাধারণ সব গিফট।
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={scrollToProducts}
                size="lg"
                className="bg-white text-primary hover:bg-gray-100 font-semibold transform hover:scale-105 transition-all"
              >
                প্রোডাক্ট দেখুন
              </Button>
              <a 
                href="https://wa.me/8801940689487" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-green-500 text-white px-8 py-4 rounded-lg font-semibold hover:bg-green-600 transition-all transform hover:scale-105 text-center inline-flex items-center justify-center"
              >
                <i className="fab fa-whatsapp mr-2"></i>
                WhatsApp এ অর্ডার
              </a>
            </div>
          </div>
          
          <div className="animate-bounce-in">
            <img 
              src="https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=400&fit=crop&crop=center" 
              alt="Custom T-Shirt showcase" 
              className="rounded-2xl shadow-2xl w-full animate-float"
            />
          </div>
        </div>
        
        {/* Stats Section */}
        <div className="grid grid-cols-3 gap-8 mt-16 animate-fade-in">
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-accent mb-2">819+</div>
            <div className="text-gray-200">খুশি গ্রাহক</div>
          </div>
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-accent mb-2">4,096+</div>
            <div className="text-gray-200">ডিজাইন</div>
          </div>
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-accent mb-2">24/7</div>
            <div className="text-gray-200">সাপোর্ট</div>
          </div>
        </div>
      </div>
    </section>
  );
}
