import { useQuery } from "@tanstack/react-query";
import ProductCard from "@/components/product/product-card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import type { Product } from "@shared/schema";

export default function ProductsSection() {
  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products/featured"],
  });

  if (isLoading) {
    return (
      <section id="products" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Skeleton className="h-8 w-32 mx-auto mb-4" />
            <Skeleton className="h-12 w-80 mx-auto mb-4" />
            <Skeleton className="h-6 w-64 mx-auto" />
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="bg-white rounded-2xl shadow-lg overflow-hidden">
                <Skeleton className="w-full h-64" />
                <div className="p-6 space-y-4">
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-8 w-1/3" />
                  <div className="flex justify-between items-center">
                    <Skeleton className="h-10 w-24" />
                    <Skeleton className="h-10 w-32" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="products" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center mb-4">
            <Badge className="bg-accent text-white px-4 py-2 text-sm font-medium">
              <i className="fas fa-star mr-2"></i>
              সেরা বিক্রেতা
            </Badge>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">আমাদের জনপ্রিয় প্রোডাক্ট</h2>
          <p className="text-gray-600 text-lg">সেরা মানের কাস্টমাইজেশন সহ</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        <div className="text-center mt-12">
          <a 
            href="https://trynex.netlify.app/products" 
            className="btn-premium text-white px-8 py-4 rounded-lg text-lg font-semibold inline-block"
          >
            সব প্রোডাক্ট দেখুন
          </a>
        </div>
      </div>
    </section>
  );
}
