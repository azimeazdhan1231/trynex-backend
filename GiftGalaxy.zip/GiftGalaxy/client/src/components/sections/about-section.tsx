export default function AboutSection() {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">কেন TryNex Lifestyle?</h2>
          <p className="text-gray-600 text-lg">আমাদের বিশেষত্ব এবং সেবা</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="text-center group">
            <div className="w-20 h-20 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
              <i className="fas fa-palette text-3xl text-white"></i>
            </div>
            <h4 className="text-xl font-semibold text-gray-800 mb-4">কাস্টম ডিজাইন</h4>
            <p className="text-gray-600 leading-relaxed">
              আপনার পছন্দ অনুযায়ী ডিজাইন করুন। নাম, ছবি, লোগো - সব কিছুই সম্ভব।
            </p>
          </div>

          <div className="text-center group">
            <div className="w-20 h-20 bg-gradient-to-r from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
              <i className="fas fa-shipping-fast text-3xl text-white"></i>
            </div>
            <h4 className="text-xl font-semibold text-gray-800 mb-4">দ্রুত ডেলিভারি</h4>
            <p className="text-gray-600 leading-relaxed">
              সারাদেশে দ্রুত এবং নিরাপদ ডেলিভারি। ঢাকায় ২৪ ঘন্টার মধ্যে।
            </p>
          </div>

          <div className="text-center group">
            <div className="w-20 h-20 bg-gradient-to-r from-accent to-orange-500 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
              <i className="fas fa-award text-3xl text-white"></i>
            </div>
            <h4 className="text-xl font-semibold text-gray-800 mb-4">প্রিমিয়াম কোয়ালিটি</h4>
            <p className="text-gray-600 leading-relaxed">
              সর্বোচ্চ মানের কাঁচামাল এবং প্রিন্টিং টেকনোলজি ব্যবহার করি।
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
