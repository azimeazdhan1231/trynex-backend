import { useCart } from "@/hooks/use-cart";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

export default function FeaturedSection() {
  const { addToCart } = useCart();
  const { toast } = useToast();

  const pandaGiftSet = {
    id: 6,
    name: "পান্ডা গিফট সেট",
    price: 1490,
    originalPrice: 2100,
    image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=600&h=400&fit=crop&crop=center"
  };

  const handleAddToCart = () => {
    addToCart({
      productId: pandaGiftSet.id,
      name: pandaGiftSet.name,
      price: pandaGiftSet.price,
      quantity: 1,
      image: pandaGiftSet.image
    });
    
    toast({
      title: "কার্টে যোগ করা হয়েছে!",
      description: `${pandaGiftSet.name} কার্টে যোগ করা হয়েছে।`,
    });
  };

  const getWhatsAppUrl = () => {
    const message = `আমি পান্ডা গিফট সেট অর্ডার করতে চাই`;
    return `https://wa.me/8801940689487?text=${encodeURIComponent(message)}`;
  };

  return (
    <section className="py-16 bg-gradient-to-r from-purple-50 to-blue-50">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center mb-4">
              <Badge className="bg-accent text-white px-4 py-2 text-sm font-medium">
                🐼 সর্বাধিক জনপ্রিয়!
              </Badge>
            </div>
            
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">পান্ডা গিফট সেট</h2>
            
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              ✨ সবকিছুই আপনি নিজের মতো করে ডিজাইন করিয়ে নিতে পারবেন — যেমন নাম, ছবি, ম্যাসেজ বা পছন্দের থিম।
              এটা একদম পার্সোনাল ও স্মরণীয় উপহার হিসেবে পারফেক্ট।
            </p>
            
            <div className="mb-6">
              <h4 className="text-xl font-semibold text-gray-800 mb-4">✅ এই সেটে থাকছে:</h4>
              <ul className="space-y-2">
                <li className="flex items-center text-gray-700">
                  <i className="fas fa-check-circle text-green-500 mr-3"></i>
                  ১টি কাস্টমাইজেবল মগ
                </li>
                <li className="flex items-center text-gray-700">
                  <i className="fas fa-check-circle text-green-500 mr-3"></i>
                  ১টি কাস্টমাইজেবল টি-শার্ট
                </li>
                <li className="flex items-center text-gray-700">
                  <i className="fas fa-check-circle text-green-500 mr-3"></i>
                  ১টি কাস্টমাইজেবল ওয়াটার টাম্বলার
                </li>
              </ul>
            </div>
            
            <div className="bg-white p-6 rounded-2xl shadow-lg mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-gray-500 line-through">রেগুলার ২১০০ টাকা</div>
                  <div className="text-3xl font-bold text-primary">🎁 অফার প্রাইস: ১৪৯০ টাকা</div>
                  <div className="text-lg font-semibold text-green-600">৬১০ টাকা ছাড়!</div>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={handleAddToCart}
                className="btn-premium font-semibold flex-1"
                size="lg"
              >
                কার্টে যোগ করুন
              </Button>
              <a 
                href={getWhatsAppUrl()}
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-green-500 text-white px-8 py-4 rounded-lg font-semibold hover:bg-green-600 transition-colors text-center flex-1 inline-flex items-center justify-center"
              >
                এখনই অর্ডার করুন
              </a>
            </div>
          </div>
          
          <div className="animate-bounce-in">
            <img 
              src={pandaGiftSet.image}
              alt="পান্ডা গিফট সেট" 
              className="rounded-2xl shadow-2xl w-full"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
