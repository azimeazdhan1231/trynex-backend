import { useCart } from "@/hooks/use-cart";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CartSidebar({ isOpen, onClose }: CartSidebarProps) {
  const { cart, updateQuantity, removeItem, clearCart, getWhatsAppUrl } = useCart();

  const scrollToProducts = () => {
    const element = document.getElementById('products');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      onClose();
    }
  };

  const handleCheckout = () => {
    if (cart.items.length === 0) {
      return;
    }

    const whatsappUrl = getWhatsAppUrl();
    window.open(whatsappUrl, '_blank');
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="right" className="w-80 flex flex-col">
        <SheetHeader>
          <SheetTitle className="text-lg font-semibold text-gray-800">আপনার কার্ট</SheetTitle>
        </SheetHeader>

        <Separator className="my-4" />

        <div className="flex-1 overflow-y-auto">
          {cart.items.length === 0 ? (
            <div className="text-center py-12">
              <i className="fas fa-shopping-cart text-4xl text-gray-300 mb-4"></i>
              <p className="text-gray-500 mb-4">আপনার কার্ট খালি</p>
              <Button onClick={scrollToProducts} className="btn-premium">
                শপিং করুন
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {cart.items.map((item) => (
                <div key={item.id} className="border-b border-gray-200 pb-4">
                  <div className="flex gap-3">
                    <img 
                      src={item.image} 
                      alt={item.name}
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-medium text-gray-800 text-sm leading-tight">
                          {item.name}
                        </h4>
                        <button 
                          onClick={() => removeItem(item.id)} 
                          className="text-red-500 hover:text-red-700 ml-2"
                        >
                          <i className="fas fa-times text-sm"></i>
                        </button>
                      </div>

                      {item.customization && (
                        <p className="text-xs text-gray-500 mb-2">{item.customization}</p>
                      )}

                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-2">
                          <button 
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="w-6 h-6 rounded border flex items-center justify-center text-gray-600 hover:bg-gray-100"
                          >
                            <i className="fas fa-minus text-xs"></i>
                          </button>
                          <span className="w-8 text-center text-sm">{item.quantity}</span>
                          <button 
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="w-6 h-6 rounded border flex items-center justify-center text-gray-600 hover:bg-gray-100"
                          >
                            <i className="fas fa-plus text-xs"></i>
                          </button>
                        </div>
                        <span className="font-semibold text-primary">৳{item.price * item.quantity}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {cart.items.length > 0 && (
          <div className="border-t border-gray-200 pt-4 space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-lg font-semibold">মোট:</span>
              <span className="text-xl font-bold text-primary">৳{cart.total}</span>
            </div>

            <div className="space-y-2">
              <Button 
                onClick={handleCheckout} 
                className="w-full btn-premium font-medium"
              >
                <i className="fab fa-whatsapp mr-2"></i>
                হোয়াটসঅ্যাপে অর্ডার করুন
              </Button>

              <Button 
                onClick={clearCart} 
                variant="outline" 
                className="w-full"
              >
                কার্ট খালি করুন
              </Button>
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}