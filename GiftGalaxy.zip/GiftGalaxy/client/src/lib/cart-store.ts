interface CartItem {
  id: string;
  productId: number;
  name: string;
  price: number;
  quantity: number;
  image: string;
  customization?: string;
}

interface CartStore {
  items: CartItem[];
  total: number;
  count: number;
}

class CartManager {
  private storageKey = 'trynex-cart';
  private listeners: (() => void)[] = [];

  getCart(): CartStore {
    if (typeof window === 'undefined') {
      return { items: [], total: 0, count: 0 };
    }

    try {
      const saved = localStorage.getItem(this.storageKey);
      const items: CartItem[] = saved ? JSON.parse(saved) : [];
      const total = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
      const count = items.reduce((sum, item) => sum + item.quantity, 0);
      
      return { items, total, count };
    } catch {
      return { items: [], total: 0, count: 0 };
    }
  }

  addItem(item: Omit<CartItem, 'id'>): void {
    const cart = this.getCart();
    const existingItem = cart.items.find(i => 
      i.productId === item.productId && i.customization === item.customization
    );

    if (existingItem) {
      existingItem.quantity += item.quantity;
    } else {
      cart.items.push({
        ...item,
        id: `${item.productId}-${Date.now()}-${Math.random()}`
      });
    }

    this.saveCart(cart.items);
    this.notifyListeners();
  }

  updateQuantity(itemId: string, quantity: number): void {
    const cart = this.getCart();
    
    if (quantity <= 0) {
      this.removeItem(itemId);
      return;
    }

    const item = cart.items.find(i => i.id === itemId);
    if (item) {
      item.quantity = quantity;
      this.saveCart(cart.items);
      this.notifyListeners();
    }
  }

  removeItem(itemId: string): void {
    const cart = this.getCart();
    const filteredItems = cart.items.filter(i => i.id !== itemId);
    this.saveCart(filteredItems);
    this.notifyListeners();
  }

  clearCart(): void {
    this.saveCart([]);
    this.notifyListeners();
  }

  private saveCart(items: CartItem[]): void {
    if (typeof window !== 'undefined') {
      localStorage.setItem(this.storageKey, JSON.stringify(items));
    }
  }

  subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notifyListeners(): void {
    this.listeners.forEach(listener => listener());
  }

  getWhatsAppMessage(): string {
    const cart = this.getCart();
    
    if (cart.items.length === 0) {
      return "আমি TryNex Lifestyle থেকে প্রোডাক্ট অর্ডার করতে চাই।";
    }

    const orderDetails = cart.items.map(item => 
      `${item.name} x ${item.quantity} = ৳${item.price * item.quantity}${item.customization ? ` (${item.customization})` : ''}`
    ).join('\n');
    
    return `আমি অর্ডার করতে চাই:\n\n${orderDetails}\n\nমোট: ৳${cart.total}`;
  }
}

export const cartManager = new CartManager();
