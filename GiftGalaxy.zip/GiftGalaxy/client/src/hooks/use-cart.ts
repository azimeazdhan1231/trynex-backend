import { useState, useEffect } from 'react';
import { cartManager } from '@/lib/cart-store';

export function useCart() {
  const [cart, setCart] = useState(cartManager.getCart());

  useEffect(() => {
    const unsubscribe = cartManager.subscribe(() => {
      setCart(cartManager.getCart());
    });

    return unsubscribe;
  }, []);

  const addToCart = (item: {
    productId: number;
    name: string;
    price: number;
    quantity: number;
    image: string;
    customization?: string;
  }) => {
    cartManager.addItem(item);
  };

  const updateQuantity = (itemId: string, quantity: number) => {
    cartManager.updateQuantity(itemId, quantity);
  };

  const removeItem = (itemId: string) => {
    cartManager.removeItem(itemId);
  };

  const clearCart = () => {
    cartManager.clearCart();
  };

  const getWhatsAppUrl = () => {
    const message = cartManager.getWhatsAppMessage();
    return `https://wa.me/8801940689487?text=${encodeURIComponent(message)}`;
  };

  return {
    cart,
    addToCart,
    updateQuantity,
    removeItem,
    clearCart,
    getWhatsAppUrl
  };
}
