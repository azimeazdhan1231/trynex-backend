import { z } from "zod";

// Admin authentication schemas
export const adminLoginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const adminCreateSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  email: z.string().email("Invalid email address"),
  role: z.enum(["admin", "super_admin"]).default("admin"),
});

// Product management schemas
export const productCreateSchema = z.object({
  name: z.string().min(1, "Product name is required"),
  nameEn: z.string().optional(),
  description: z.string().min(1, "Description is required"),
  descriptionEn: z.string().optional(),
  price: z.number().min(0, "Price must be positive"),
  originalPrice: z.number().min(0, "Original price must be positive").optional(),
  category: z.string().min(1, "Category is required"),
  image: z.string().url("Invalid image URL"),
  images: z.array(z.string().url()).default([]),
  isCustomizable: z.boolean().default(true),
  isFeatured: z.boolean().default(false),
  discountPercentage: z.number().min(0).max(100).default(0),
  specialOffer: z.string().optional(),
  inStock: z.boolean().default(true),
});

export const productUpdateSchema = productCreateSchema.partial();

// Order management schemas
export const orderUpdateSchema = z.object({
  status: z.enum(["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"]),
  notes: z.string().optional(),
});

// Analytics schemas
export const analyticsFilterSchema = z.object({
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  category: z.string().optional(),
  status: z.string().optional(),
});

// Category management schemas
export const categorySchema = z.object({
  name: z.string().min(1, "Category name is required"),
  nameEn: z.string().optional(),
  description: z.string().optional(),
  image: z.string().url("Invalid image URL").optional(),
  isActive: z.boolean().default(true),
});

// Customer schemas
export const customerSchema = z.object({
  name: z.string().min(1, "Customer name is required"),
  phone: z.string().min(10, "Valid phone number required"),
  email: z.string().email("Invalid email address").optional(),
  address: z.string().optional(),
  totalOrders: z.number().default(0),
  totalSpent: z.number().default(0),
});

// Settings schemas
export const siteSettingsSchema = z.object({
  siteName: z.string().min(1, "Site name is required"),
  siteDescription: z.string().optional(),
  logo: z.string().url("Invalid logo URL").optional(),
  contactPhone: z.string().min(10, "Valid phone number required"),
  contactEmail: z.string().email("Invalid email address"),
  whatsappNumber: z.string().min(10, "Valid WhatsApp number required"),
  address: z.string().optional(),
  socialMedia: z.object({
    facebook: z.string().url().optional(),
    instagram: z.string().url().optional(),
    twitter: z.string().url().optional(),
  }).optional(),
  deliverySettings: z.object({
    dhakaDeliveryTime: z.string().default("24 hours"),
    outsideDhakaDeliveryTime: z.string().default("3-5 days"),
    deliveryCharge: z.number().min(0).default(60),
  }).optional(),
});

export type AdminLogin = z.infer<typeof adminLoginSchema>;
export type AdminCreate = z.infer<typeof adminCreateSchema>;
export type ProductCreate = z.infer<typeof productCreateSchema>;
export type ProductUpdate = z.infer<typeof productUpdateSchema>;
export type OrderUpdate = z.infer<typeof orderUpdateSchema>;
export type AnalyticsFilter = z.infer<typeof analyticsFilterSchema>;
export type Category = z.infer<typeof categorySchema>;
export type Customer = z.infer<typeof customerSchema>;
export type SiteSettings = z.infer<typeof siteSettingsSchema>;